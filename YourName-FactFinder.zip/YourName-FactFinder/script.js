
function ffct1(){
	document.getElementById('textbox').innerHTML = "<b>There is an annual Coffee Break Festival.:</b><br> <img src='images/fact1.jpg' alt='friends drinking coffe'>";
	
}
function ffct2(){
	document.getElementById('textbox').innerHTML = "<b>You can buy a flying bicycle.:</b><br><img src='images/fact2.jpg' alt='kid'>";
	
}
function ffct3(){
	document.getElementById('textbox').innerHTML = "<b>Dolphins sleep with one eye open.:</b><br><img src='images/fact3.jpg'>";
	
}
function ffct4(){
	document.getElementById('textbox').innerHTML = "<b>The largest padlock in the world weighs 916 pounds.:</b><br><img src='images/fact4.jpg'>";
	
}
function ffct5(){
	document.getElementById('textbox').innerHTML = "<b>McDonald's introduced drive-through service due to the military.:</b><br><img src='images/fact5.jpg'>";
	
}
function theme1(){
 
  document.querySelector('body').style.backgroundColor="#4B0743";
  document.querySelector('body').style.color="#AB947E";
  document.querySelector('section').style.borderColor="#162C64";
  document.querySelector('section').style.backgroundColor="#39304A";
  document.getElementById('textbox').style.color="green";
  
}
function theme2(){
  document.querySelector('body').style.backgroundColor="#A0DDE6";
   document.querySelector('body').style.color="#2A2D34";
   document.querySelector('section').style.borderColor="#30C5FF";
   document.querySelector('section').style.bakgroundColor="#F39237";
    document.getElementById('textbox').style.color="blue";
   
}
function theme3(){
  document.querySelector('body').style.backgroundColor="#F39237";
  document.querySelector('body').style.color="#D63230";
  document.querySelector('section').style.backgroundColor="#D63230";
  document.querySelector('section').style.color="#F7E3AF";
}